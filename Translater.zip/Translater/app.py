from flask import Flask, request, render_template
import openai

app = Flask(__name__)
openai.api_key = 'Your API KEY'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/translate', methods=['POST'])
def translate_text():
    english_text = request.form['english_text']
    translation = translate_to_creole(english_text)
    return render_template('index.html', translation=translation)


@app.route('/regenerate', methods=['POST'])
def regenerate_translation():
    english_text = request.form['english_text']
    translation = translate_to_creole(english_text)
    return render_template('index.html', english_text=english_text, translation=translation)


def translate_to_creole(text):
    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a translator."},
            {"role": "user", "content": f"Translate the following text to: {text}"} # Enter the language you wish to translate to
        ]
    )
    translation = response.choices[0].message['content'].strip()
    return translation

if __name__ == '__main__':
    app.run(debug=True)

