document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('copy-button').addEventListener('click', function() {
        var text = document.getElementById('translation-text').innerText;
        navigator.clipboard.writeText(text).then(function() {
            alert('Translation copied to clipboard!');
        }, function(err) {
            console.error('Could not copy text: ', err);
        });
    });

    document.getElementById('regenerate-button').addEventListener('click', function() {
        var englishText = document.querySelector('textarea[name="english_text"]').value;
        fetch('/regenerate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                'english_text': englishText
            })
        })
        .then(response => response.text())
        .then(html => {
            document.open();
            document.write(html);
            document.close();
        })
        .catch(error => console.error('Error:', error));
    });
});

