from flask import Flask, render_template, request, redirect, url_for, session, abort
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import concurrent.futures
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import html2text
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Custom filter for enumerating
@app.template_filter('enumerate')
def enumerate_filter(iterable, start=0):
    return enumerate(iterable, start=start)

# Global variable to store scraped URLs
scraped_urls = []

def get_all_urls(base_url):
    error_message = None

    # Send a GET request to the base URL
    response = requests.get(base_url)

    # Try different encodings
    for encoding in ['utf-8', 'latin-1', 'windows-1252']:
        try:
            response.encoding = encoding
            soup = BeautifulSoup(response.text, 'html.parser', exclude_encodings=['utf-8', 'latin-1', 'windows-1252'])
            break
        except UnicodeDecodeError:
            print(f"Error decoding with {encoding} encoding. Trying next encoding...")
    else:
        error_message = f"Failed to decode the response using the specified encodings for {base_url}."
        return [], error_message

    # Check if the request was successful
    if response.status_code == 200:
        # Find all <a> tags which contain links
        links = soup.find_all('a')

        # Extract the href attribute from each <a> tag
        all_urls = []
        for link in links:
            href = link.get('href')
            if href:
                # Join the URL with the base URL to handle relative URLs
                full_url = urljoin(base_url, href)
                # Ignore URLs ending with .pdf or .mp3
                if not full_url.endswith(('.pdf', '.mp3')):
                    all_urls.append(full_url)

        return all_urls, error_message
    else:
        error_message = f"Unfortunately we are unable to scrap this site, try another website. {base_url}. Status code: {response.status_code}"
        return [], error_message

def extract_text_from_url(url):
    try:
        # Send a GET request to the URL
        response = requests.get(url)

        # Try different encodings
        for encoding in ['utf-8', 'latin-1', 'windows-1252']:
            try:
                response.encoding = encoding
                soup = BeautifulSoup(response.text, 'html.parser', exclude_encodings=['utf-8', 'latin-1', 'windows-1252'])
                break
            except UnicodeDecodeError:
                print(f"Error decoding with {encoding} encoding. Trying next encoding...")
        else:
            print(f"Failed to decode {url} using the specified encodings.")
            return f"Failed to extract text from {url}"

        # Check if the request was successful
        if response.status_code == 200:
            # Extract all text from the webpage
            text = soup.get_text()
            return text
        else:
            print(f"Failed to retrieve {url}. Status code: {response.status_code}")
            return f"Failed to extract text from {url}"
    except requests.exceptions.RequestException as e:
        print(f"Error occurred while fetching {url}: {e}")
        return f"Failed to extract text from {url}"

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        base_url = request.form['base_url']
        scraped_urls, error_message = get_all_urls(base_url)
        session['scraped_urls'] = scraped_urls
        return render_template('index.html', base_url=base_url, all_urls=scraped_urls, error_message=error_message)

    base_url = session.get('base_url', '')
    scraped_urls = session.get('scraped_urls', [])
    error_message = None
    return render_template('index.html', base_url=base_url, all_urls=scraped_urls, error_message=error_message)


@app.route('/extract_text', methods=['POST'])
def extract_text():
    try:
        selected_urls = request.form.getlist('url')

        # Use a thread pool to extract text concurrently
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [executor.submit(extract_text_from_url, url) for url in selected_urls]
            extracted_texts = [(url, future.result()) for url, future in zip(selected_urls, futures)]

        return render_template('text.html', extracted_texts=extracted_texts)

    except Exception as e:
        if '502' in str(e):
            error_message = 'System overload, please try extracting fewer URLs at a time.'
            return render_template('text.html', error=error_message)
        else:
            raise e


@app.route('/download_text', methods=['POST'])
def download_text():
    selected_texts = request.form.getlist('selected_text')

    # Create a PDF document
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Convert HTML to plain text
    h = html2text.HTML2Text()

    for text in selected_texts:
        try:
            plain_text = h.handle(text)
            elements.append(Paragraph(plain_text, styles['BodyText']))
        except Exception as e:
            print(f"Error converting text to PDF: {e}")
            continue

    # Build the PDF document
    doc.build(elements)

    # Reset the pointer to the beginning of the buffer
    buffer.seek(0)

    # Create the response with the PDF file
    response = app.response_class(
        buffer.getvalue(),
        mimetype='application/pdf',
        headers={
            'Content-Disposition': 'attachment; filename=extracted_text.pdf'
        }
    )

    return response

@app.route('/back_to_list', methods=['GET'])
def back_to_list():
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)