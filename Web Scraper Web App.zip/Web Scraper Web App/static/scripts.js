function selectAll() {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length && i < 20; i++) {
        checkboxes[i].checked = true;
    }
}

function clearUrls() {
    // Clear the list of scraped URLs
    var urlList = document.querySelectorAll('label');
    for (var i = 0; i < urlList.length; i++) {
        urlList[i].remove();
    }

    // Reset the URL counter
    var urlCounter = document.getElementById('url-counter');
    urlCounter.textContent = 'Number of URLs extracted: 0';
}

function validateForm() {
    var baseUrl = document.querySelector('input[name="base_url"]').value;
    var errorMessage = document.getElementById('error-message');

    if (baseUrl.trim() === '') {
        errorMessage.textContent = 'Please enter a base URL.';
        return false;
    }

    errorMessage.textContent = '';
    return true;
}

function validateExtractForm() {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    var extractError = document.getElementById('extract-error');

    if (checkboxes.length === 0) {
        extractError.textContent = 'Please select at least one URL to extract text.';
        return false;
    }

    extractError.textContent = '';
    return true;
}

function selectAllText() {
    var checkboxes = document.querySelectorAll('input[name="selected_text"]');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true;
    }
}