import customtkinter as ctk                                      # Import the customtkinter library for creating GUI applications
from CTkMessagebox import CTkMessagebox                          # Import the CTkMessagebox class from the CTkMessagebox module
from PIL import Image                                            # Import the Image module from the PIL (Python Imaging Library) for handling images
import socket                                                    # Import the socket module for creating network sockets
 
# Define global variables for entry fields
password_entry = None                                            # Variable to store password input
product_code_entry = None                                        # Variable to store product code input
product_name_entry = None                                        # Variable to store product name input
price_entry = None                                               # Variable to store price input
quantity_entry_admin = None                                      # Variable to store quantity input for administrative purposes
product_id_entry = None                                          # Variable to store product ID input
quantity_entry_order = None                                      # Variable to store quantity input for order

# Function to send order to server
def send_order(order):                       
    HOST = '127.0.0.1'                                                               # Host IP address where the server is running
    PORT = 5555                                                                      # Port number on which the server is listening

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:                    # Creating a socket object
        s.connect((HOST, PORT))                                                     # Connecting to the server
        s.sendall(order.encode())                                                   # Sending the order to the server in encoded format
        data = s.recv(1024)                                                         # Receiving response from the server


    # Displaying a messagebox with the received product data
    CTkMessagebox(title="Order Placed", icon="check", icon_size=(35,35) ,corner_radius=20, fg_color="#2b2b2b", button_color="#87df00", button_hover_color="#383839",  justify="right", button_width=150, message=f"Received: {data.decode()}", option_1="OK")


# Function to request and display products from the server
def get_products():
    HOST = '127.0.0.1'
    PORT = 5555

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        s.sendall("GET_PRODUCTS".encode())
        data = s.recv(1024).decode()

    # Displaying a messagebox with the received product data
    CTkMessagebox(title="Products", corner_radius=20, fg_color="#2b2b2b", button_color="#1f1f1f",button_hover_color="#87df00", justify="right", button_width=150, message=data, option_1="OK", icon=None,)

# Function to request and display inventory of all products from the server
def get_inventory():
    HOST = '127.0.0.1'
    PORT = 5555

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        s.sendall("GET_INVENTORY".encode())
        data = s.recv(1024).decode()
    

    # Displaying a messagebox with the received product data
    CTkMessagebox(title="Inventory",corner_radius=20, fg_color="#2b2b2b", button_color="#1f1f1f",button_hover_color="#87df00", justify="right", button_width=150, message=data, option_1="OK", icon=None)



# Function to add product to the database
def add_product():
    # Prompt for admin password
    password = password_entry.get()                                                         # Get the password entered by the user

    # Check if the password is correct
    if password == "waajid987":  
        product_code = product_code_entry.get()                                             # Get the product code entered by the user
        product_name = product_name_entry.get()                                             # Get the product name entered by the user
        price = price_entry.get()                                                           # Get the price entered by the user
        quantity = quantity_entry_admin.get()                                               # Get the quantity entered by the user for administrative purposes

        # Construct the order string
        order = f"ADD_PRODUCT {product_code} {product_name} {price} {quantity}"             # Constructing the order string

        # Send the order to the server
        send_order(order)                                                                   # Calling the send_order function to send the order to the server
    else:                    
        CTkMessagebox(title="Access Denied", message="Incorrect password. Access denied.", option_1="OK")         # Display a messagebox indicating access denied due to incorrect password



# Main function for client interfaces
def main():
    root = ctk.CTk()                                                                                                       # Create the root window
    root.title("")                                                                                                         # Set the title of the window (empty in this case)
    root.geometry("500x250")                                                                                               # Set the dimensions of the window (500x250)

    font_2 = ("Poppins", 15, "bold")                                                                                       # Define a font for text
    welcome_message = ctk.CTkLabel(root, text="Welcome to the Vending Heaven", font=font_2)                                # Create a label with a welcome message
    welcome_message.place(x=245,y=10)                                                                                      # Place the welcome message label at the specified position

    vending_machine_picture = ctk.CTkImage(light_image=Image.open("vending-machine (1).png"), size=(180,190))              # Load an image of a vending machine

    vending_Label = ctk.CTkLabel(root, text="", image=vending_machine_picture)                                             # Create a label with the vending machine picture
    vending_Label.place(x=265,y=40)                                                                                        # Place the vending machine picture label at the specified position




    # Function to show order window
    def show_order_window():
        order_window = ctk.CTkToplevel(root)                                        # Create a new top-level window for the order
        order_window.title("Order")                                                 # Set the title of the order window
        order_window.geometry("1200x155")                                           # Set the dimensions of the order window



        font_2 = ("Poppins", 13, "bold")




        #                                                                                                  # Define images for each product
        candy_picture_1 = ctk.CTkImage(light_image=Image.open("softdrinks.png"), size=(90,90))

        candy_picture_2 = ctk.CTkImage(light_image=Image.open("chocolate-bar6566.png"), size=(90,90))

        candy_picture_3 = ctk.CTkImage(light_image=Image.open("cookies.png"), size=(90,90))

        candy_picture_4 = ctk.CTkImage(light_image=Image.open("chocolate-bar (1).png"), size=(90,90))

        candy_picture_5 = ctk.CTkImage(light_image=Image.open("products.png"), size=(90,90))

        candy_picture_6 = ctk.CTkImage(light_image=Image.open("water-bottle.png"), size=(90,90))

        candy_picture_7 = ctk.CTkImage(light_image=Image.open("candy (2).png"), size=(90,90))



        #                                                                                                   # Create labels for each product with corresponding images and product codes
        candy_label_1 = ctk.CTkLabel(order_window, text="", image=candy_picture_1)                          # Label for product 1
        candy_label_1.place(x=300, y=25)
        product_code_1 = ctk.CTkLabel(order_window, text="A001", font=font_2)                               # Product code for product 1
        product_code_1.place(x=300, y=25)

        candy_label_2 = ctk.CTkLabel(order_window, text="", image=candy_picture_2)                          # Label for product 2
        candy_label_2.place(x=430, y=25)
        product_code_2 = ctk.CTkLabel(order_window, text="A003", font=font_2)                               # Product code for product 2
        product_code_2.place(x=420, y=25)

        candy_label_3 = ctk.CTkLabel(order_window, text="", image=candy_picture_3)                          # Label for product 3
        candy_label_3.place(x=560, y=25)
        product_code_3 = ctk.CTkLabel(order_window, text="A007", font=font_2)                               # Product code for product 3
        product_code_3.place(x=560, y=25)

        candy_label_4 = ctk.CTkLabel(order_window, text="", image=candy_picture_4)                          # Label for product 4
        candy_label_4.place(x=690, y=25)
        product_code_4 = ctk.CTkLabel(order_window, text="A005", font=font_2)                               # Product code for product 4
        product_code_4.place(x=680, y=25)

        candy_label_5 = ctk.CTkLabel(order_window, text="", image=candy_picture_5)                          # Label for product 5
        candy_label_5.place(x=820, y=25)
        product_code_5 = ctk.CTkLabel(order_window, text="A002", font=font_2)                               # Product code for product 5
        product_code_5.place(x=790, y=25)

        candy_label_6 = ctk.CTkLabel(order_window, text="", image=candy_picture_6)                          # Label for product 6
        candy_label_6.place(x=950, y=25)
        product_code_6 = ctk.CTkLabel(order_window, text="A004", font=font_2)                               # Product code for product 6
        product_code_6.place(x=930, y=25)

        candy_label_7 = ctk.CTkLabel(order_window, text="", image=candy_picture_7)                          # Label for product 7
        candy_label_7.place(x=1080, y=25)
        product_code_7 = ctk.CTkLabel(order_window, text="A006", font=font_2)                               # Product code for product 7
        product_code_7.place(x=1050, y=25)




     #--------------------------------------------------------------------------            Labels and entry fields for ordering products        --------------------------------------------------------------------------#



        font_1 = ("Poppins", 12, "bold")

        
        product_id_label = ctk.CTkLabel(order_window, text="Product ID:", font=font_1)
        product_id_label.grid(row=0, column=0, padx=10, pady=10)
        global product_id_entry
        product_id_entry = ctk.CTkEntry(order_window, corner_radius=50)
        product_id_entry.grid(row=0, column=1, padx=10, pady=10)

        quantity_label = ctk.CTkLabel(order_window, text="Quantity:", font=font_1)
        quantity_label.grid(row=1, column=0, padx=10, pady=10)
        global quantity_entry_order
        quantity_entry_order = ctk.CTkEntry(order_window, corner_radius=50)
        quantity_entry_order.grid(row=1, column=1, padx=10, pady=10)
        

        # Button to place order
        order_button = ctk.CTkButton(order_window, text="Place Order", font=font_1, fg_color="#1f1f1f", hover_color="#df0133", border_width=2, border_color="#df0133", width=120, height=30, corner_radius=50, command=lambda: handle_order())
        order_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)


      #------------------------------------------------------------------------          Function to show admin window       --------------------------------------------------------------------------------------------#
        


    def show_admin_window():
        admin_window = ctk.CTkToplevel(root)
        admin_window.title("Admin Privileges")
        admin_window.geometry("700x300")

        font_2 = ("Poppins", 15, "bold")
        admin_message = ctk.CTkLabel(admin_window, text="Vending Machine Configuration", font=font_2)
        admin_message.place(x=410,y=10)

        vending_admin = ctk.CTkImage(light_image=Image.open("admin.png"), size=(180,190))

        vending_con_label = ctk.CTkLabel(admin_window, text="", image=vending_admin)
        vending_con_label.place(x=420,y=40)


        font_1 = ("Poppins", 12, "bold")

        # Label for admin password
        password_label = ctk.CTkLabel(admin_window, text="Admin Password:", font=font_1)
        password_label.grid(row=0, column=0, padx=10, pady=10)
        global password_entry
        password_entry = ctk.CTkEntry(admin_window, corner_radius=50, border_color="#2596be")
        password_entry.grid(row=0, column=1, padx=10, pady=10)


        #----------------------------------------------------------------------      Labels and entry fields for adding products     ------------------------------------------------------------------------------------#


        product_code_label = ctk.CTkLabel(admin_window, text="Product Code:", font=font_1)
        product_code_label.grid(row=1, column=0, padx=10, pady=10)
        global product_code_entry
        product_code_entry = ctk.CTkEntry(admin_window, corner_radius=50, border_color="#f2b95c")
        product_code_entry.grid(row=1, column=1, padx=10, pady=10)

        product_name_label = ctk.CTkLabel(admin_window, text="Product Name:", font=font_1)
        product_name_label.grid(row=2, column=0, padx=10, pady=10)
        global product_name_entry
        product_name_entry = ctk.CTkEntry(admin_window, corner_radius=50, border_color="#f2b95c")
        product_name_entry.grid(row=2, column=1, padx=10, pady=10)

        price_label = ctk.CTkLabel(admin_window, text="Price:", font=font_1)
        price_label.grid(row=3, column=0, padx=10, pady=10)
        global price_entry
        price_entry = ctk.CTkEntry(admin_window, corner_radius=50, border_color="#f2b95c")
        price_entry.grid(row=3, column=1, padx=10, pady=10)

        quantity_label = ctk.CTkLabel(admin_window, text="Quantity:", font=font_1)
        quantity_label.grid(row=4, column=0, padx=10, pady=10)
        global quantity_entry_admin
        quantity_entry_admin = ctk.CTkEntry(admin_window, corner_radius=50, border_color="#f2b95c")
        quantity_entry_admin.grid(row=4, column=1, padx=10, pady=10)

        # Button to add product
        add_product_button = ctk.CTkButton(admin_window, text="Add Product", font=font_1, fg_color="#1f1f1f", hover_color="#f2b95c", width=370, height=30, corner_radius=50, command=lambda: add_product())
        add_product_button.place(x=320,y=250)

    # Function to handle order
    def handle_order():
        product_id = product_id_entry.get()                                 # Get the product ID entered by the user
        quantity = quantity_entry_order.get()                               # Get the quantity entered by the user for the order
        order = f"ORDER {product_id} {quantity}"                            # Construct the order string
        send_order(order)                                                   # Send the order to the server
        

    # Function to handle choice selection
    def handle_choice(choice):                                              # Check the user's choice and perform corresponding actions
        if choice == "1":
            get_products()                                                  # Call the function to view products
        elif choice == "2":
            get_inventory()                                                 # Call the function to view inventory
        elif choice == "3":
            show_order_window()
        elif choice == "4":                                                 # Call the function to show the order window
            show_admin_window()                                             # Call the function to show the admin window
        elif choice == "5":
            root.destroy()                                                  # Exit the program

    font_1 = ("Poppins", 12, "bold")

    # Buttons for different functionalities
    buttons = [
        ("View Products", "1"),                                 # Button to view products
        ("View Inventory", "2"),                                # Button to view inventory
        ("Order", "3"),                                         # Button to place an order
        ("Admin Privileges", "4"),                              # Button to access admin privileges
        ("Exit", "5")                                           # Button to exit the program
    ]

    for text, choice in buttons:
        button = ctk.CTkButton(root, text=text, font=font_1, fg_color="#1e1e1e", hover_color="#ff6977", width=120, height=30, corner_radius=50, command=lambda choice=choice: handle_choice(choice))
        button.grid(row=int(choice), column=0, padx=10, pady=10)

    root.mainloop()                                                          # Start the main event loop to display the GUI and handle user events

if __name__ == "__main__":
    main()                                                                   # Call the main function if this script is executed directly