import socket                                 # Import the socket module for network communication
import mysql.connector                        # Import the MySQL connector module for database interaction
from datetime import datetime                 # Import the datetime module to work with dates and times



# MySQL connection configuration
db_config = {
    'host': 'localhost',                            # Hostname where the MySQL database server is running
    'user': 'root',                                 # Username for connecting to the database
    'password': 'waajidbunbun007',                  # Password for connecting to the database
    'database': 'vending_machine_stock'             # Name of the database to connect to             
}


def process_transaction(order, db_connection, conn):
    cursor = db_connection.cursor()
    #                                                                       # Process order and update database
    #                                                                       # Write transaction to a file
    with open("transactions.txt", "a") as file:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        #                                                                    # Split the order string to extract product code and quantity
        order_parts = order.split()
        product_code = order_parts[1]                                        # Extract the product code from the order
        quantity = int(order_parts[2])                                       # Extract the quantity from the order and convert it to an integer
        
        cursor.execute("SELECT quantity FROM products WHERE product_code = %s", (product_code,))                 # Check if the product is available in stock
        result = cursor.fetchone()                                                                               # Fetch the result of the query, which should be the quantity of the product in stock




        
        if result:                                                                                                      # Check if the product was found in the database (result is not None)
            available_quantity = result[0]                                                                              # Extract the available quantity from the fetched result
            if available_quantity >= quantity:                                                                          # Check if the available quantity is sufficient for the order                 
                #                                                                                                       # Fetch product name and price from the database
                cursor.execute("SELECT name, price FROM products WHERE product_code = %s", (product_code,))
                product_info = cursor.fetchone()                                                                        # Fetch the product information (name, price)
                product_name = product_info[0]                                                                          # Extract the product name from the fetched information
                price = product_info[1]                                                                                 # Extract the product price from the fetched information
                
                #                                                                                                      # Calculate the total amount
                total_amount = quantity * price
                
            
                file.write(f"{timestamp}: Product Code: {product_code}, Product Name: {product_name}, Quantity: {quantity}, Total Amount: {total_amount}\n")            # Write transaction details to the file
                
               
                cursor.execute("UPDATE products SET quantity = quantity - %s WHERE product_code = %s", (quantity, product_code))                                        # Update the database (reduce the quantity of purchased items)
                db_connection.commit()
                
                
                conn.send("Order processed successfully".encode())                             # Send success message to the client
                
                
                send_updated_inventory(conn, cursor)                                           # After processing the order, send updated inventory to the client
            else:
              
                conn.send("Error: Product is out of stock".encode())                           # Send error message to the client if product is out of stock
        else:
            
            conn.send("Error: Invalid product code".encode())                                   # Send error message to the client if product code is invalid

    cursor.close()




def send_updated_inventory(conn, cursor):                                       # Function to send updated inventory to the client
  
    cursor.execute("SELECT product_code, name, quantity FROM products")         # Fetch inventory of all products from the database
    inventory = cursor.fetchall()

  
    inventory_str = "\n".join([f"{item['product_code']}: {item['name']} - Quantity: {item['quantity']}" for item in inventory])             # Prepare inventory data for sending


    conn.sendall(inventory_str.encode())                                                    # Send inventory data to the client


#----------------------------------------------------------  Function defining the updating inventory queries 1 ----------------------------------------------------------#

def add_product(data, db_connection, conn):
    try:
        cursor = db_connection.cursor()
        # Split the data string to extract product details
        _, product_code, product_name, price, quantity = data.split()
        price = float(price)
        quantity = int(quantity)
        # Check if the product code already exists
        cursor.execute("SELECT COUNT(*) FROM products WHERE product_code = %s", (product_code,))
        count = cursor.fetchone()[0]
        if count == 0:
            # Insert new product into the database
            cursor.execute("INSERT INTO products (product_code, name, price, quantity) VALUES (%s, %s, %s, %s)", (product_code, product_name, price, quantity))
            db_connection.commit()
            conn.sendall("Product added successfully".encode())
        else:
            # Update quantity of existing product in the database
            cursor.execute("UPDATE products SET quantity = quantity + %s WHERE product_code = %s", (quantity, product_code))
            db_connection.commit()
            conn.sendall("Quantity updated successfully".encode())
    except Exception as e:
        conn.sendall(f"Error: {e}".encode())



#----------------------------------------------------------  Function defining the updating inventory queries 2 ----------------------------------------------------------#

def handle_client(conn, addr):
    print(f"Connected to {addr}")

    try:
        db_connection = mysql.connector.connect(**db_config)
        cursor = db_connection.cursor(dictionary=True)

        while True:
            data = conn.recv(1024).decode()
            if not data:
                break
            print(f"Received request: {data}")

            if data == "GET_PRODUCTS":
                # Fetch products from the database
                cursor.execute("SELECT product_code, name, price FROM products")
                products = cursor.fetchall()

                # Prepare products data for sending
                products_str = "\n".join([f"{product['product_code']}: {product['name']} - ${product['price']}" for product in products])

                # Send products data to the client
                conn.sendall(products_str.encode())

            elif data == "GET_INVENTORY":
                # Fetch inventory of all products from the database
                cursor.execute("SELECT product_code, name, quantity FROM products")
                inventory = cursor.fetchall()

                # Prepare inventory data for sending
                inventory_str = "\n".join([f"{item['product_code']}: {item['name']} - Quantity: {item['quantity']}" for item in inventory])

                # Send inventory data to the client
                conn.sendall(inventory_str.encode())

            elif data.startswith("ADD_PRODUCT"):
                # Process adding new product to the database
                add_product(data, db_connection, conn)

            else:
                # Process order and update database
                process_transaction(data, db_connection, conn)

#-------------------------------------------------------------------  Error Handling Exceptions  ---------------------------------------------------------------#

    except Exception as e:
        print(f"Error: {e}")

    finally:
        db_connection.close()
        conn.close()
        print(f"Connection with {addr} closed")





#-------------------------------------------------------------------------------    Server configuration  -------------------------------------------------------#
HOST = '127.0.0.1'  # localhost
PORT = 5555

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

print(f"Server listening on {HOST}:{PORT}")

#----------------------------------------------------------    Function to create products table and insert initial data  ------------------------------------------------#
def initialize_database():
    db_connection = mysql.connector.connect(**db_config)
    cursor = db_connection.cursor()

#---------------------------------------------------------                 Create products table if not exists           --------------------------------------------------#
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_code VARCHAR(10) PRIMARY KEY,
            name VARCHAR(255),
            price DECIMAL(6, 2),
            quantity INT
        )
    """)

#---------------------------------------------------------              Insert initial data if table is empty                  --------------------------------------------------#
    
    cursor.execute("SELECT COUNT(*) FROM products")
    count = cursor.fetchone()[0]
    if count == 0:
        cursor.execute("""
            INSERT INTO products (product_code, name, price, quantity) VALUES
            ('A001', 'Coke', 1.50, 10),
            ('A002', 'Chips', 1.00, 15),
            ('A003', 'Snickers', 1.25, 8),
            ('A004', 'Water', 1.00, 20),
            ('A005', 'Chocolate Bar', 1.75, 12),
            ('A006', 'Granola Bar', 1.50, 18)
        """)

    db_connection.commit()                      # Commit the transaction to the database
    cursor.close()                              # Close the cursor and the database connection
    db_connection.close()


initialize_database()                          # Initialize the database
 
while True:                                    # Infinite loop to continuously accept connections and handle clients
    conn, addr = server.accept()               # Accept a new connection from a client
    handle_client(conn, addr)                  # Handle the client
