from flask import Flask, request, render_template, redirect, url_for
import moviepy.editor as mp
import os
import openai
import speech_recognition as sr

app = Flask(__name__)
openai.api_key = 'Your API KEY'

# Ensure the uploads directory exists
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_video():
    if 'video' not in request.files:
        return redirect(url_for('index'))

    video = request.files['video']
    if video.filename == '':
        return redirect(url_for('index'))

    video_path = os.path.join(UPLOAD_FOLDER, video.filename)
    video.save(video_path)

    # Extract audio from video
    audio_path = extract_audio(video_path)

    # Transcribe audio
    transcription = transcribe_audio(audio_path)

    return render_template('index.html', transcription=transcription)

def extract_audio(video_path):
    video = mp.VideoFileClip(video_path)
    audio_path = video_path.replace('.mp4', '.wav')
    video.audio.write_audiofile(audio_path)
    return audio_path

def transcribe_audio(audio_path):
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio_path) as source:
        audio = recognizer.record(source)

    try:
        transcription = recognizer.recognize_google(audio)
    except sr.UnknownValueError:
        transcription = "Google Speech Recognition could not understand audio"
    except sr.RequestError as e:
        transcription = f"Could not request results from Google Speech Recognition service; {e}"

    # If needed, translate the transcription to Mauritian Creole here using GPT
    translation = openai.ChatCompletion.create(
        model="gpt-4",  # Use the newer GPT-4 model
        messages=[
            {"role": "system", "content": "You are a translator."},
            {"role": "user", "content": f"Translate the following text to Mauritian Creole: {transcription}"}
        ]
    ).choices[0].message['content'].strip()

    return translation

if __name__ == '__main__':
    app.run(debug=True)
