#----------------------------------------------------------------     Import all necessary modules    ------------------------------------------------------------------#

import customtkinter
from tkinter import *                    # Importing all elements from tkinter module
from tkinter import messagebox           # Importing messagebox from tkinter module to display dialog boxes
import threading                         # Importing threading module to operate multiple tasks simultaneously
import math                              # Importing math module for mathematical operations
import requests                          # Importing requests module for making HTTP requests



#------------------------------------------------------    Code Block for API Requests obtaining currency Rates     ---------------------------------------------------#



def convert_currency(amount, from_currency, to_currency): 

    app_id = '534e23c63f534655b40ae6d447486779'                          # API key for accessing currency conversion service
    base_url = 'https://open.er-api.com/v6/latest/{}'                    # Base URL for accessing currency exchange rates

    try:
        response = requests.get(base_url.format(from_currency))          # Get the most recent currency rates through the API
        data = response.json()                                           # Extract data from response
        
        rates = data['rates']                                            # Extracted exchange rates

        
        if from_currency != 'USD':                                       # Convert the amount to the base currency (USD)
            amount = amount / rates[from_currency]

        
        converted_amount = amount * rates[to_currency]                   # Convert the amount from the base currency to the target currency
        return converted_amount                                          # Return converted amount

    except Exception:                                                    # Handle any errors that occur during conversion process
        print("Error")
        return None





#-----------------------------------------------------    All Functions in Relation To the Main Calculator         ----------------------------------------------------#
    

def show(value):                                                         # Function to update the equation entry with the provided value
    current = equation_entry.get()                                       # Get the current value in the equation entry
    equation_entry.delete(0, END)                                        # Clear the equation entry                                                   
    equation_entry.insert(END, current + value)                          # Insert the updated value (current value + provided value) into the equation entry
 



def calculate():                                                                                               # Function to start new thread for performing calculation
    expression = equation_entry.get()                                                                          # Get expression from equation entry
    calculation_thread = threading.Thread(target=perform_calculation, args=(expression,))                      # Create new thread for performing the calculation
    calculation_thread.start()                                                                                 # Start calculation thread



def perform_calculation(expression):                                             # Function to perform calculation based on the provided expression
    try:
        result = eval(expression)                                                # Evaluate expression and get the result
        app.after(0, update_output, result)                                      # Schedule the update_output function to be called with the result after 0 milliseconds
    except ZeroDivisionError:                                                    # Catch ZeroDivisionError if division by zero occurs
        app.after(0, update_output, "Error: Division by zero")                   # Schedule the update_output function to be called with an error message after 0 milliseconds
    except Exception:                                                            # Catch any other exceptions
        app.after(0, update_output, "Error")                                     # Schedule the update_output function to be called with a general error message after 0 milliseconds
    


def power_of_2():                                                    # Function to calculate the power of 2 of the current value in the equation entry
    current = equation_entry.get()                                   # Get current value in the equation entry
    equation_entry.delete(0, END)                                    # Clear equation entry
    equation_entry.insert(END, f"({current})**2")                    # Insert the expression to calculate the power of 2 of the current value into equation entry




def sin_function():                                                  # Function to calculate sine of the value in the equation entry
    try: 
        value = float(equation_entry.get())                          # Get value from the equation entry and convert it to float
        result = math.sin(math.radians(value))                       # Calculate sine of the value (assuming value is in degrees) and update the output
        update_output(result)
    except ValueError:                                               # Handle case where value cannot be converted to float
        update_output("Error")

    

def tan_function():                                                  # Function to calculate tangent of the value in the equation entry
    try:
        value = float(equation_entry.get())                          # Get value from the equation entry and convert it to a float
        result = math.tan(math.radians(value))                       # Calculate tangent of the value (assuming value is in degrees) and update the output
        update_output(result)
    except ValueError:                                               # Handle case where value cannot be converted to float
        update_output("Error")                                        



def cos_function():                                                  # Function to calculate the cosine of the value in the equation entry
    try:
        value = float(equation_entry.get())                          # Get value from the equation entry and convert it to a float
        result = math.cos(math.radians(value))                       # Calculate the cosine of the value (assuming value is in degrees) and update the output
        update_output(result)
    except ValueError:                                               # Handle case where value cannot be converted to float
        update_output("Error")                                 


def sqrt_function():                                                 # Function to calculate the square root of the value in the equation entry
    try:
        value = float(equation_entry.get())                          # Get the value from the equation entry and convert it to a float
        result = math.sqrt(value)                                    # Calculate the square root of the value and update the output
        update_output(result)
    except ValueError:                                               # Handle case where value cannot be converted to float
        update_output("Error")


def log_function():                                                  # Function to calculate the base-10 logarithm of the value in the equation entry
    try:
        value = float(equation_entry.get())                          # Get the value from the equation entry and convert it to a float
        result = math.log10(value)                                   # Calculate the base-10 logarithm of the value and update the output
        update_output(result)
    except ValueError:                                               # Handle case where value cannot be converted to float
        update_output("Error")



def percentage_function():                                           # Function to calculate the percentage of the value in the equation entry
    try:
        value = float(equation_entry.get())                          # Get the value from the equation entry and convert it to a float
        result = value / 100                                         # Calculate the percentage of the value and update the output
        update_output(result)
    except ValueError:                                               # Handle case where value cannot be converted to float
        update_output("Error")                                     



def cbrt_function():                                                 # Function to calculate the cube root of the value in the equation entry
    try:
        value = float(equation_entry.get())                          # Get the value from the equation entry and convert it to a float
        result = value ** (1/3)                                      # Calculate the cube root of the value and update the output
        update_output(result)
    except ValueError:                                               # Handle case where value cannot be converted to float
        update_output("Error")



def update_output(result):                                           # Function to update the output entry with the provided result
    answer_entry.delete(0, END)                                      # Clear current content of output entry
    answer_entry.insert(END, str(result))                            # Insert result into output entry


def clear():                                                         # Function to clear the equation entry and output entry
    equation_entry.delete(0, END)                                    # Clear content of equation entry
    answer_entry.delete(0, END)                                      # Clear content of output entry




def open_bracket():                 # Function to insert an open bracket "(" into the equation_entry
    show("(")

def close_bracket():                # Function to insert a close bracket ")" into the equation_entry
    show(")")




#------------------------------------------------------------------------     CustomTkinter Window and Font Set Up    -----------------------------------------------------------------------#


app = customtkinter.CTk()
app.title("Calculator")
app.geometry("700x530")
app.bind("<KeyPress-c>", lambda event: converter())         # Key binding "c" to the convert button 
app.bind("<Return>", lambda event: calculate())             # Key binding "Enter" to the equal button 
app.bind("<BackSpace>", lambda event: clear())              # Key binding "BackSpace" to the clear button 

font_1 = ("Poppins", 20, "bold")
font_2 = ("Poppins", 40, "bold")
font_3 = ("Poppins", 15, "bold")
font_4 = ("Poppins", 13, "bold")




#--------------------------------------------------------------------------------    Entry Boxes Set Up     -----------------------------------------------------------------------------------#


equation_entry = customtkinter.CTkEntry(app, textvariable="", font=font_1, width=600, height=70, fg_color="#202020",border_color="#000000", corner_radius=40)
equation_entry.place(x=50, y=20)

answer_entry = customtkinter.CTkEntry(app, placeholder_text="=^. _ .^=", textvariable="", font=font_2, width=600, height=70, fg_color="#202020", border_color="#000000", corner_radius=40, justify=RIGHT)
answer_entry.place(x=50, y=105)




#--------------------------------------------------------------------------   Calculator Button Set Up and Placement     ---------  ------------------------------------------------------------#


# Clear Button
Button_clear = customtkinter.CTkButton(app, command=clear, font=font_1, width=85, height=45, fg_color="#094076", hover_color="#042A5D", text="C", corner_radius= 5, text_color="#000000")
Button_clear.place(x=20, y=200)

# Equal Button
Button_Equal = customtkinter.CTkButton(app, command=calculate, text="=", font=font_1, width=195, height=45, fg_color="#094076", hover_color="#042A5D", text_color="#000000")
Button_Equal.place(x=20, y=460)

# Maths Operation 1
Button_A = customtkinter.CTkButton(app, command=lambda: show("-"), text="‒", font=font_3, width=85, height=45, fg_color="#094076", hover_color="#042A5D", text_color="#000000")
Button_A.place(x=335, y=395)

# Maths Operation 2
Button_B = customtkinter.CTkButton(app, command=lambda: show("+"), text="+", font=font_1, width=85, height=45, fg_color="#094076", hover_color="#042A5D", text_color="#000000")
Button_B.place(x=335, y=460)

# Maths Operation 3
Button_C = customtkinter.CTkButton(app, command=lambda: show("*"), text="×", font=font_1, width=85, height=45, fg_color="#094076", hover_color="#042A5D", text_color="#000000")
Button_C.place(x=335, y=330)

# Maths Operation 4
Button_D = customtkinter.CTkButton(app, command=lambda: show("/"), text="÷", font=font_1, width=85, height=45, fg_color="#094076", hover_color="#042A5D", text_color="#000000")
Button_D.place(x=335, y=265)

# Maths Operation 5 
Button_E = customtkinter.CTkButton(app, command=power_of_2, text="ⅹ²", font=font_1, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_E.place(x=600, y=265)

# Maths Operation 6
Button_F = customtkinter.CTkButton(app, command=sin_function, text="Sinθ", font=font_3, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_F.place(x=500, y=395)

# Maths Operation 7
Button_G = customtkinter.CTkButton(app, command=tan_function, text="Tanθ", font=font_3, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_G.place(x=500, y=460)


# Maths Operation 8
Button_H = customtkinter.CTkButton(app, command=cos_function, text="Cosθ", font=font_3, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_H.place(x=500, y=330)

# Maths Operation 9
Button_I = customtkinter.CTkButton(app, command=sqrt_function, text="√", font=font_1, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_I.place(x=600, y=395)

# Maths Operation 10
Button_J = customtkinter.CTkButton(app, command=log_function, text="Log", font=font_3, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_J.place(x=500, y=265)

# Maths Operation 11
Button_K = customtkinter.CTkButton(app, command=percentage_function, text="%", font=font_1, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_K.place(x=600, y=460)

# Maths Operation 12
Button_L = customtkinter.CTkButton(app, command=cbrt_function, text="∛", font=font_1, width=85, height=45, fg_color="#737373", hover_color="#2D3134", text_color="#000000")
Button_L.place(x=600, y=330)

# Button 1
Button_1 = customtkinter.CTkButton(app, command=lambda: show("7"), text="7", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_1.place(x=20, y=265)

# Button 2
Button_2 = customtkinter.CTkButton(app, command=lambda: show("8"), text="8", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_2.place(x=120, y=265)

# Button 3
Button_3 = customtkinter.CTkButton(app, command=lambda: show("9"), text="9", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_3.place(x=230, y=265)

# Button 4
Button_4 = customtkinter.CTkButton(app, command=lambda: show("4"), text="4", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_4.place(x=20, y=330)

# Button 5
Button_5 = customtkinter.CTkButton(app, command=lambda: show("5"), text="5", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_5.place(x=120, y=330)

# Button 6
Button_6 = customtkinter.CTkButton(app, command=lambda: show("6"), text="6", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_6.place(x=230, y=330)

# Button 7
Button_7 = customtkinter.CTkButton(app, command=lambda: show("1"), text="1", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_7.place(x=20, y=395)

# Button 8
Button_8 = customtkinter.CTkButton(app, command=lambda: show("2"), text="2", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_8.place(x=120, y=395)

# Button 9
Button_9 = customtkinter.CTkButton(app, command=lambda: show("3"), text="3", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_9.place(x=230, y=395)

# Button 0
Button_0 = customtkinter.CTkButton(app, command=lambda: show("0"), text="0", font=font_1, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_0.place(x=230, y=460)

# Button for open bracket "("
Button_OpenBracket = customtkinter.CTkButton(app, command=open_bracket, text="(", font=font_3, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_OpenBracket.place(x=120, y=200)

# Button for close bracket ")"
Button_CloseBracket = customtkinter.CTkButton(app, command=close_bracket, text=")", font=font_3, width=85, height=45, fg_color="#323334", hover_color="#1D1E20")
Button_CloseBracket.place(x=230, y=200)



#-------------------------------------------------------------------      Currency Converter Set Up   ------------------------------------------------------------------------------#


def converter():
    app_2 = customtkinter.CTkToplevel(app)
    app_2.title("Converter")
    app_2.geometry("700x420")


    title1_label= customtkinter.CTkLabel(app_2, text= "Currency Converter", font=font_3)
    title1_label.place(x=100, y=10)

    from_label= customtkinter.CTkLabel(app_2, text="From", font=font_4, text_color="#FFFFFF" )
    from_label.place(x=20,y=50)

    to_label= customtkinter.CTkLabel(app_2, text="To", font=font_4, text_color="#FFFFFF" )
    to_label.place(x=30,y=100)




 #---------------------------------------------------------       Functions Related to the Currency Converter         --------------------------------------------------------------#
    

    currency_lists=["USD",               # List of currency codes
                    "EUR", 
                    "GBP", 
                    "CAD", 
                    "CNY", 
                    "JPY", 
                    "INR", 
                    "DKK", 
                    "AUD", 
                    "BRL",
                    "NZD",
                    "MUR"]

    variable1=StringVar()              # Variable to store the selected value from the first dropdown menu
    variable2=StringVar()              # Variable to store the selected value from the second dropdown menu
    txt=StringVar()                    # Variable to store txt input


    def convert():                                                                            # Get selected currencies and amount from the user inputs
        from_currency = variable1.get()                                                       # Get value of the selected currency to convert from
        to_currency = variable2.get()                                                         # Get value of the selected currency to convert to
        amount = (amount_entry.get())                                                         # Get amount to be converted


        try:
            amount = float(amount)                                                            # Convert the input amount to a floating-point number
        except ValueError:                                                                    # Show error message if the entered amount is not a valid number
            messagebox.showerror("Error", "Please enter a valid number")
            return

        if amount <= 0:                                                                       # Show error message if the entered amount is not positive
            messagebox.showerror("Error", "Please enter a positive number")
            return

       
        converted_amount = convert_currency(amount, from_currency, to_currency)               # Call the function to perform currency conversion


        if converted_amount is not None:                                                      # If conversion is successful, update the displayed converted amount
            converted_text = f"{converted_amount:.2f} {to_currency}"                          # Format the converted amount
            txt.set(converted_text)                                                           # Set the converted text to be displayed
        
        else:                                                                                 # If conversion fails, display an error message                                          
            txt.set("Error: Unable to convert")                                               # Set the error message to be displayed
            txt.set(converted_text)



        result_label = customtkinter.CTkLabel(app_2, textvariable=txt, font=font_3)           # Result of conversion to be displayed set up and placement 
        result_label.place(x=400, y=100)


    def reset():                                                                              # Function to reset the amount entry field
        amount_entry.delete(0,END)                                                            # Delete content of amount entry field
 



    #---------------------------------------------------   Other Currency Converter BUtton and Entry Set Up   -----------------------------------------------------------------------#


    from_currency_dropdown= customtkinter.CTkComboBox(app_2, variable=variable1, values=currency_lists, width=200, height=35, corner_radius=50, font=font_3, fg_color="#2D3134", border_color="#2D3134", button_color="#2D3134", button_hover_color="#000000", dropdown_fg_color="#2D3134", dropdown_hover_color="#000000", dropdown_font= font_4, justify=CENTER )
    from_currency_dropdown.place(x=70,y=50)

    to_currency_dropdown= customtkinter.CTkComboBox(app_2, variable=variable2, values=currency_lists, width=200, height=35, corner_radius=50, font=font_3, fg_color="#2D3134", border_color="#2D3134", button_color="#2D3134", button_hover_color="#000000", dropdown_fg_color="#2D3134", dropdown_hover_color="#000000", dropdown_font= font_4, justify=CENTER)
    to_currency_dropdown.place(x=70,y=100)

    amount_entry=customtkinter.CTkEntry(app_2, width=250, height=35, corner_radius=50, font=font_4, fg_color="#094076", border_color="#094076", justify=CENTER, placeholder_text="Enter Value")
    amount_entry.place(x=300,y=50)

    convert_currency_button=customtkinter.CTkButton(app_2, command=convert, text="Convert", font=font_3, width=85, height=35, fg_color="#737373", hover_color="#2D3134", corner_radius= 30, text_color="#000000")
    convert_currency_button.place(x=580,y=50)

    reset_currency_button=customtkinter.CTkButton(app_2, command=reset, text="Reset", font=font_3, width=92, height=35, fg_color="#737373", hover_color="#2D3134", corner_radius= 30, text_color="#000000")
    reset_currency_button.place(x=585,y=100)




 
  #-----------------------------------------------------------------------------      Metric Converter Set Up  -------------------------------------------------------------------------------#
    

    unit_options = ["Volume", "Mass", "Data", "Time"]                                              # List of unit options
    volume_choices = ["Liter", "Mililiter", "Gallon", "Quart", "Pint"]                             # Options for volume conversion
    mass_choices = ["Kilogram", "Gram", "Pound", "Ton", "Ounce", "Stone"]                          # Options for mass conversion
    data_choices = ["Byte", "Kilobyte", "Megabyte", "Gigabyte", "Terabyte", "Petabyte"]            # Options for data conversion
    time_choices = ["Second", "Minute", "Hour", "Day", "Week", "Month", "Year"]                    # Options for time conversion
    


    volume_aspects = {"Liter": 1,                                 # Conversion factors for volume
                      "Milliliter": 0.001, 
                      "Gallon": 3.78541, 
                      "Quart": 0.946353, 
                      "Pint": 0.473176}
        
    mass_aspects = {"Kilogram": 1,                               # Conversion factors for mass
                    "Gram": 0.001, 
                    "Ton": 1000,
                    "Ounce": 0.0283495,
                    "Pound": 0.453592,
                    "Stone": 6.35029}
        
    data_aspects = {"Byte": 1,                                   # Conversion factors for data
                    "Kilobyte": 1024,
                    "Megabyte": 1048576,
                    "Gigabyte": 1073741824,
                    "Terabyte": 1099511627776,
                    "Petabyte": 1125899906842624}
        
    time_aspects = {"Second": 1,                                 # Conversion factors for time
                    "Minute": 60,
                    "Hour": 3600,
                    "Day": 86400,
                    "Week": 604800,
                    "Month": 2629800,  
                    "Year": 31557600}

    
    unit_option_variable= StringVar()         # Variable to store the selected unit option
    variable4= StringVar()                    # Variable to store the selected volume option
    variable5= StringVar()                    # Variable to store the selected mass option

    def convert_unit():                                                                                   # Function to perform conversion based on selected units
        try:
            value = float(value_entry.get())                                                              # Get the value to be converted and convert it to float
            if value < 0:                                                                                 # Check if the entered value is negative
                raise ValueError("Negative values are not allowed.")
        
            if unit_option_variable.get() == "Volume":                                                    # Volume conversion
                liters = float(value_entry.get()) * volume_aspects[variable4.get()]                       # Convert the entered value to liters based on selected volume unit
                converted_value = liters / volume_aspects[variable5.get()]                                # Convert liters to the selected volume unit
            
            elif unit_option_variable.get() == "Data":                                                    # Data conversion
                bytes_value = float(value_entry.get()) * data_aspects[variable4.get()]                    # Convert the entered value to bytes based on selected data unit
                converted_value = bytes_value / data_aspects[variable5.get()]                             # Convert bytes to the selected data unit

            elif unit_option_variable.get() == "Time":                                                    # Time conversion
                seconds = float(value_entry.get()) * time_aspects[variable4.get()]                        # Convert the entered value to seconds based on selected time unit
                converted_value = seconds / time_aspects[variable5.get()]                                 # Convert seconds to the selected time unit
                    
            else:                                                                                         # Mass conversion
                kilograms = float(value_entry.get()) * mass_aspects[variable4.get()]                      # Convert the entered value to kilograms based on selected mass unit
                converted_value = kilograms / mass_aspects[variable5.get()]                               # Convert kilograms to the selected mass unit



            result_unit_label.configure(text=f"{value_entry.get()} {variable4.get()} = {converted_value:.2f} {variable5.get()}")          # Update the result label with the conversion result


        
        except ValueError:                                                             # Catch ValueError if non-numeric characters are entered
            messagebox.showerror("ERROR", "Digits Only")

        except:                                                                        # Catch other exceptions
            messagebox.showerror("ERROR", "Please Enter a Valid Value")

    
    def update_options(*args):                                                         # Function to update the options in the dropdown menus based on the selected unit
        if unit_option_variable.get() == "Volume":                                     # If volume is selected, configure the dropdown menus with volume options
            from_unit_option.configure(values=volume_choices)                          # Set values for 'from' dropdown menu
            to_unit_option.configure(values=volume_choices)                            # Set values for 'to' dropdown menu
            from_unit_option.set("Litre")                                              # Set default value for 'from' dropdown menu
            to_unit_option.set("Pint")                                                 # Set default value for 'to' dropdown menu

        elif unit_option_variable.get() == "Data":                                     # If data is selected, configure the dropdown menus with data options
            from_unit_option.configure(values=data_choices)
            to_unit_option.configure(values=data_choices)
            from_unit_option.set("Byte")
            to_unit_option.set("Kilobyte")

        elif unit_option_variable.get() == "Time":                                     # If time is selected, configure the dropdown menus with time options
            from_unit_option.configure(values=list(time_choices))
            to_unit_option.configure(values=list(time_choices))
            from_unit_option.set("Second")
            to_unit_option.set("Minute")

        else:                                                                           # If mass is selected, configure the dropdown menus with mass options
            from_unit_option.configure(values=mass_choices)
            to_unit_option.configure(values=mass_choices)
            from_unit_option.set("Kilogram")
            to_unit_option.set("Gram")

    unit_option_variable.trace("w", update_options)                                     # Attach the update_options function to the unit_option_variable trace
    
    def reset1():                                                                       # Function to clear the value entry field
        value_entry.delete(0,END)                                                       # Delete the content of the value entry field



 

  #--------------------------------------------------------     Metric Converter Button Set Up and Placements       ------------------------------------------------------------------------------#

    title_label=customtkinter.CTkLabel(app_2, font=font_3, text="Unit Converter",)
    title_label.place(x=120,y=190)

    unit_metric_label=customtkinter.CTkLabel(app_2, font=font_4, text="Metric",)
    unit_metric_label.place(x=20,y=227)

    unit_option=customtkinter.CTkComboBox(app_2, values=unit_options, variable=unit_option_variable, width=200, height=35, corner_radius=50, font=font_3, fg_color="#2D3134", border_color="#2D3134", button_color="#2D3134", button_hover_color="#000000", dropdown_fg_color="#2D3134", dropdown_hover_color="#000000", dropdown_font= font_4, justify=CENTER )
    unit_option.place(x=70,y=225)

    from_unit_label=customtkinter.CTkLabel(app_2, font=font_4, text="From",)
    from_unit_label.place(x=20,y=275)

    from_unit_option=customtkinter.CTkComboBox(app_2, variable=variable4,  width=200, height=35, corner_radius=50, font=font_3, fg_color="#2D3134", border_color="#2D3134", button_color="#2D3134", button_hover_color="#000000", dropdown_fg_color="#2D3134", dropdown_hover_color="#000000", dropdown_font= font_4, justify=CENTER  )
    from_unit_option.place(x=70,y=275)

    to_unit_label=customtkinter.CTkLabel(app_2, font=font_4, text="To",)
    to_unit_label.place(x=30,y=325)

    to_unit_option=customtkinter.CTkComboBox(app_2, variable=variable5,  width=200, height=35, corner_radius=50, font=font_3, fg_color="#2D3134", border_color="#2D3134", button_color="#2D3134", button_hover_color="#000000", dropdown_fg_color="#2D3134", dropdown_hover_color="#000000", dropdown_font= font_4, justify=CENTER  )
    to_unit_option.place(x=70,y=325)


    value_entry = customtkinter.CTkEntry(app_2, width=250, height=35, corner_radius=50, font=font_4, fg_color="#094076", border_color="#094076", justify=CENTER, placeholder_text="Enter Value" )
    value_entry.place(x=300,y=227)

    
    convert_unit_button=customtkinter.CTkButton(app_2, command=convert_unit,  text="Convert", font=font_3, width=85, height=35, fg_color="#737373", hover_color="#2D3134", corner_radius= 30, text_color="#000000" )
    convert_unit_button.place(x=580,y=227)

    reset_unit_button=customtkinter.CTkButton(app_2, command=reset1, text="Reset", font=font_3, width=95, height=35, fg_color="#737373", hover_color="#2D3134", corner_radius= 30, text_color="#000000")
    reset_unit_button.place(x=585,y=275)

    result_unit_label = customtkinter.CTkLabel(app_2,text="", font=font_3, )
    result_unit_label.place(x=330,y=275)




#------------------------------------------------------------    From Main Calculator Switch to COnverter    ----------------------------------------------------------------------#


# Converter Button
Button_Converter = customtkinter.CTkButton(app, command=converter, font=font_1, width=350, height=45, fg_color="#094076", hover_color="#042A5D", text="Converter", corner_radius= 50, text_color="#000000")
Button_Converter.place(x=335, y=200)


app.mainloop()               # Run the Calculator Application


#-----------------------------------------------------------------------------    End Of Script  ---------------------------------------------------------------------------------#
